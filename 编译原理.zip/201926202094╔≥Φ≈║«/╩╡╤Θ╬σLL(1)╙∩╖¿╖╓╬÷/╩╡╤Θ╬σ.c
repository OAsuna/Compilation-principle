/*Z->bMb					
M->a
M->(L
L->Ma)

bab#
b(aa)b#
*/

#include "stdio.h"
#include "conio.h"
#define MAX 20
typedef struct{
 char data[20];
 int top;
} stack;

void initstack(stack *st)
{
 st->top=0;
}

void push(stack *st,char ch)
{
 if(st->top==MAX-1) { printf("\nstack is full!"); getch();exit(0); }
 st->data[st->top]=ch;
 st->top++;
}

void pop(stack *st)
{
 if(st->top==0) { printf("\nstack is empty!"); getch();exit(0);}
  st->top--;
}

char read(stack *st)
{
  return st->data[st->top-1];
}

void error()
{
  printf("\nerror!");
  getch();
  exit(0);
}

int is_vt( char ch)
{
  int i;
  switch(ch)
  {
   case 'Z':i=0; break;
   case 'M':i=0; break;
   case 'L':i=0; break;
   case 'a':i=1; break;
   case 'b':i=1; break;
   case '(':i=1; break;
   case ')':i=1; break;
   default: printf("\ncharacter is false!");getch();exit(0);
  }
  return i;
}

int vn_to_int(char ch)
{
  int i;
  switch(ch)
  {
   case 'Z':i=0;break;
   case 'M':i=1;break;
   case 'L':i=2;break;
   default: printf("\ncharacter is false!");getch();exit(0);
  }
  return i;
}

int vt_to_int(char ch)
{
  int i;
  switch(ch)
  {
   case 'a':i=0;break;
   case 'b':i=1;break;
   case '(':i=2;break;
   case ')':i=3;break;
   case '#':i=4;break;
   default: printf("\ncharacter is false!");getch();exit(0);
  }
  return i;
}

void LL_driver(stack *input,stack *sem,int LL[3][5])
{
  int k;
  char is,ss;
  is=read(input);
  ss=read(sem);
  while( ss!='#')
  {
   if(is_vt(ss))
     {
      if(is==ss) { pop(input); pop(sem);}
       else error();
      }
    else
     {
        case 1: pop(sem);push(sem,'b'); push(sem,'M');push(sem,'b'); break;
        case 2: pop(sem);push(sem,'a');
       k=LL[vn_to_int(ss)][vt_to_int(is)];
       switch(k)
       {break;
        case 3: pop(sem);push(sem,'L'); push(sem,'('); break;
        case 4: pop(sem);push(sem,')'); push(sem,'a'); push(sem,'M');break;
        case -1:error();
       }
      }
   is=read(input);
   ss=read(sem);
  }
  if(is=='#'&& ss=='#') { printf("\naccept!"); getch(); }
    else error();
}

main()
{
   int LL[3][5]={-1,1,-1,-1,-1,2,-1,3,-1,-1,4,-1,4,-1,-1};
  char c,ch[MAX];
  stack input,sem ;
  int i=0,j;

  initstack(&input);
  initstack(&sem);
  printf("\ninput a string:");
  scanf("%c",&c);
  while(c!='#')
   {
    ch[i]=c;
    i++;
    scanf("%c",&c);
   }
  
  ch[i]='#';
  for(j=i;j>=0;j--) printf("%c",ch[j]);
  for(j=i;j>=0;j--)
    push(&input,ch[j]); 
  push(&sem,'#');
  push(&sem,'Z');
  LL_driver(&input,&sem,LL);       
}
