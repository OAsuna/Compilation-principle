#include <iostream>
#include "string.h"
#include "cf.h"


using namespace std;


FILE *f1;
struct aa
{
    int clas;
    char seman[10];
}token8[80];
char intBox[30][30];
char charBox[30][30];
char floatBox[30][30];
int p=0;
int int_num=0,char_num=0,float_num=0;
int hang=1;
int errornum=0;

void error(int linetemp){
  	fprintf(f1,"��%d�д��󣡣�����ʶ���ظ����塣\n",linetemp);
  	printf("��%d�д���,�ظ������ʶ��\n",linetemp);
  	errornum++;
}
void error2(int linetemp){
	fprintf(f1,"��%d�д��󣡣�����ʶ��δ���塣\n",linetemp);
	printf("��%d�д���,δ�����ʶ��\n",linetemp);
	errornum++;
}
void errorFile(){
	printf("\nδ�ҵ����ļ���");
}
void errorNull(int linetemp){
	fprintf(f1,"��%d�д��󣡣���\n",linetemp);
	printf("��%d�д���\n",linetemp);
}
void drive(){
	int state=0;
	int flag=0;
	int ch;
	ch=token8[p].clas;
	printf("\n%s : state:%d\n",token8[p].seman,state);
	while(1){
		switch(state){
			case 0:if(ch==9)state=1;        //int
				   else if(ch==8)state=6;   //float
				   else if(ch==10)state=16; //char
				   else if(ch==11)state=10; //��ʶ��
				   else if(ch==12)state=18; //����
			       else if(ch==1||ch==3||ch==4)state=12;    //if,for,while
			       else if(ch==38)return;   //����
				   else{errorNull(hang); return;}
				   break;
			case 1:p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==11)state=2;break;
			case 2:
				if(int_num!=0){
					int q=0;
					while(q<int_num){
						if(strcmp(token8[p].seman,intBox[q++])==0){
							flag=1;error(hang);break;
						}
					}
				}
				if(float_num!=0){
					int q=0;
					while(q<float_num){
						if(strcmp(token8[p].seman,floatBox[q++])==0){
							flag=1;error(hang);break;
						}
					}
				}
				if(char_num!=0){
					int q=0;
					while(q<char_num){
						if(strcmp(token8[p].seman,charBox[q++])==0){
							flag=1;error(hang);break;
						}
					}
				}
				if(flag==0){
					strcpy(intBox[int_num],token8[p].seman);
					int_num++;
				}
				flag=0;
				p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==28){state=4;}
				else if(ch==35)state=20;
				break;
            case 3:
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==37){
					hang++;printf("\nline: %d��\n",hang);
				}
				return;//37�Ż���
			case 4:
				p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==12){state=5;}
				else if(ch==11){state=10;}
				break;
            case 5:
				p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==35)state=20;
				else if(ch==13||ch==14||ch==15||ch==16)state=19;
				break;
            case 6:
				p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				state=7;
				if(ch==11){state=7;}
				break;
            case 7:
				if(float_num!=0){
					int q=0;
					while(q<float_num){
						if(strcmp(token8[p].seman,floatBox[q++])==0){
							flag=1;error(hang);break;
						}
					}
				}
				if(int_num!=0){
					int q=0;
					while(q<int_num){
						if(strcmp(token8[p].seman,intBox[q++])==0){
							flag=1;error(hang);break;
						}
					}
				}
				if(char_num!=0){
					int q=0;
					while(q<char_num){
						if(strcmp(token8[p].seman,charBox[q++])==0){
							flag=1;error(hang);break;
						}
					}
				}
				if(flag==0){
					strcpy(floatBox[float_num],token8[p].seman);float_num++;
				}
				flag=0;
				p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==28)state=4;
				else if(ch==35)state=20;
				break;
            case 8:
				if(char_num!=0){
					int q=0;
					while(q<char_num){
						if(strcmp(token8[p].seman,charBox[q++])==0){
							flag=1;error(hang);break;
						}
					}
				}
				if(float_num!=0){
					int q=0;
					while(q<float_num){
						if(strcmp(token8[p].seman,floatBox[q++])==0){
							flag=1;error(hang);break;
						}
					}
				}
				if(int_num!=0){
					int q=0;
					while(q<int_num){
						if(strcmp(token8[p].seman,intBox[q++])==0){
							flag=1;error(hang);break;
						}
					}
				}
				if(flag==0){
					strcpy(charBox[char_num],token8[p].seman);char_num++;
				}
				flag=0;
				p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==28)state=4;
				else if(ch==35){state=20;}
				break;
            case 10:
				if(float_num!=0){
					int q=0;
					while(q<float_num){
						if(strcmp(token8[p].seman,floatBox[q++])==0){
							flag=1;break;
						}
					}
				}
				if(int_num!=0){
					int q=0;
					while(q<int_num){
						if(strcmp(token8[p].seman,intBox[q++])==0){
							flag=1;break;
						}
					}
				}
				if(char_num!=0){
					int q=0;
					while(q<char_num){
						if(strcmp(token8[p].seman,charBox[q++])==0){
							flag=1;break;
						}
					}
				}
				if(flag==0)error2(hang);
				flag=0;
				p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==28)state=4;
				else if(ch==13)state=11;
				else if(ch==18||ch==19||ch==7||ch==8||ch==22||ch==23){
					state=14;
				}
				else if(ch==32)state=15;
				else if(ch==35)state=20;
				else if(ch==38)return;
				break;
            case 11:
				p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==11)state=10;
				break;
			case 12:
				p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==31)state=13;
				break;
			case 13:
				p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==11)state=10;
				else if(ch==12)state=17;
				break;
			case 14:
				p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==11)state=10;
				else if(ch==12)state=17;
				break;
			case 15:
				p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==11)state=10;
				break;
			case 16:
				p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==11)state=8;break;
			case 17:
				 p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==18||ch==19||ch==7||ch==8||ch==22||ch==23)state=14;
				else if(ch==32)state=15;
				else if(ch==35)state=20;
				break;
			case 18:
				p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==13||ch==14||ch==15||ch==16||ch==28)state=19;
				else if(ch==35)state=20;
				else if(ch==32)state=21;
				break;
			case 19:
				p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==12)state=18;
				else if(ch==35)state=20;
				break;
			case 20:
				p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==37){
					state=3;
				}
				else if(ch==11){
					state=10;
				}
				else if(ch==12)state=5;
				else if(ch==38)return;
				break;
			case 21:
				p++;ch=token8[p].clas;
				printf("\n%s : state:%d\n",token8[p].seman,state);
				if(ch==13||ch==14||ch==15||ch==16)state=19;
				break;
			default: errorNull(hang);return;
		}
    }
    return;
}




int main()
{
    maincc();
    int j=0;
    printf("�������\n");
    FILE* f=fopen("tokenxl.txt","r");
    f1=fopen("error.txt","w");
	if(f==NULL){errorFile();}
	int i=0;
	while(!feof(f)){
		fscanf(f,"%d %s\n",&token8[i].clas,&token8[i].seman);
		i++;
	}

	fclose(f);
    while(p<i){
        drive();
        p++;
        if(token8[p].clas==38){
        	break;
		}
    }
    int n;
    printf("�Ѷ���int��");
    for(n=0;n<int_num;n++){
    	printf("%s",intBox[n]);
	}
	printf("\n�Ѷ���float��");
	for(n=0;n<float_num;n++){
    	printf("%s",floatBox[n]);
	}
	printf("\n�Ѷ���char��");
	for(n=0;n<char_num;n++){
    	printf("%s",charBox[n]);
	}
    if(p==i){
        if(errornum==0){
        	printf("\n���������");
		}
		else{
            printf("\n��%d������",errornum);
		}
    }
  	return 0;
}
