#include <iostream>
#include "cifa.cpp"

/* 0. S->E   */
/* 1. E->E+T  */
/* 2. E->T     */
/* 3. T->T*P   */
/* 4. T->P  */
/* 5. P->i    */
/* 6. P->(E)  */

/*
S->E
E->E+T
E->E-T
E->T
T->T*F
T->T/F
T->F
F->(E)
F->id
F->num 

*/
#include "stdio.h"
#include "conio.h"
#define MAX 500

typedef struct{
  char left;
  int  length;
} production;

void create_production(production p[10])
{
 p[0].left='S';   p[0].length=1;
 p[1].left='E';   p[1].length=3;
 p[2].left='E';   p[2].length=3;
 p[3].left='E';   p[3].length=1;
 p[4].left='T';   p[4].length=3;
 p[5].left='T';   p[5].length=3;
 p[6].left='T';   p[6].length=1;

 p[7].left='F';   p[7].length=3;
 p[8].left='F';   p[8].length=1;
 p[9].left='F';   p[9].length=1;
}

typedef struct{
 int data[20];
 int top;
} state_stack;

typedef struct{
 int data[20];
 int top;
} char_stack;

void init_state_stack(state_stack *st)
{
 st->top=0;
}

void init_char_stack(char_stack *st)
{
 st->top=0;
}

void state_push(state_stack *st,int s)
{
 if(st->top==MAX-1) { printf("\nstack is full!"); getch();exit(0); }
 st->data[st->top]=s;
 st->top++;
}

void char_push(char_stack *st,int ch)
{
 if(st->top==MAX-1) { printf("\nstack is full!"); getch();exit(0); }
 st->data[st->top]=ch;
 st->top++;
}

void state_pop(state_stack *st)
{
 if(st->top==0) { printf("\nstack is empty!"); getch();exit(0);}
  st->top--;
}

void char_pop(char_stack *st)
{
 if(st->top==0) { printf("\nstack is empty!"); getch();exit(0);}
  st->top--;
}

int read_state(state_stack *st)
{
  return st->data[st->top-1];
}

int read_char(char_stack *st)
{
  return st->data[st->top-1];
}

void error()
{
  printf("\nerror!");
  getch();
  exit(0);
}

int vn_to_int(char ch)
{
  int i;
  switch(ch)
  {
   case 'E':i=0;break;
   case 'T':i=1;break;
   case 'F':i=2;break;
  }
  return i;
}

int vt_to_int(int ch)
{
  int i;
  switch(ch)
  {
   case 13:i=0;break;
   case 14:i=1;break;
   case 15:i=2;break;
   case 16:i=3;break;
   case 31:i=4;break;
   case 32:i=5;break;
   case 11:i=6;break;
   case 12:i=7;break;
   case 38:i=8;break;
   default: printf("\ncharacter is false!");getch();exit(0);
  }
  return i;
}

void SLR_driver(state_stack *state,char_stack *input,char action1[17][9],
          int action2[17][9],int SLR_goto[17][3], production p[10] )
{
  int s,k,l,m;
  int c,ch;
  s=read_state(state);
  ch=read_char(input);
  //printf("s=%d,ch=%c",s,ch);
  while(1)
  {

     k=vt_to_int(ch);
     c=action1[s][k];

     switch(c)
     {
     case 's': state_push(state,action2[s][k]); char_pop(input); break;
     case 'r': m=action2[s][k];
               for(l=p[m].length;l>0;l--)
                 state_pop(state);
               state_push(state,SLR_goto[read_state(state)][vn_to_int(p[m].left)]);
               break;
     case 'a': printf("\naccept!"); getch(); exit(0);
     default: error();
     }

     s=read_state(state);
     ch=read_char(input);
    //printf("\ns=%d,ch=%c",s,ch);
 }
}
main()
{
  char c;
  int ch[MAX];
  int i=0,lll=0,j=0;
  state_stack state;
  char_stack input;
  char action1[17][9]={
      {'0','0','0','0','s','0','s','s','0'},
      {'s','s','0','0','0','0','0','0','a'},
      {'r','r','s','s','0','r','0','0','r'},
      {'r','r','r','r','0','r','0','0','r'},
      {'0','0','0','0','s','0','s','s','0'},
      {'r','r','r','r','0','r','0','0','r'},
      {'r','r','r','r','0','r','0','0','r'},
      {'0','0','0','0','s','0','s','s','0'},
      {'0','0','0','0','s','0','s','s','0'},
      {'0','0','0','0','s','0','s','s','0'},
      {'0','0','0','0','s','0','s','s','0'},
      {'s','s','0','0','0','s','0','0','0'},
      {'r','r','s','s','0','r','0','0','r'},
      {'r','r','s','s','0','r','0','0','r'},
      {'r','r','r','r','0','r','0','0','r'},
      {'r','r','r','r','0','r','0','0','r'},
      {'r','r','r','r','0','r','0','0','r'}};
  int action2[17][9]={
      {-1,-1,-1,-1,4,-1,5,6,-1},
      {7,8,-1,-1,-1,-1,-1,-1,-1},
      {3,3,9,10,-1,3,-1,-1,3},
      {6,6,6,6,-1,6,-1,-1,6},
      {-1,-1,-1,-1,4,-1,5,6,-1},
      {8,8,8,8,-1,8,-1,-1,8},
      {9,9,9,9,-1,9,-1,-1,9},
      {-1,-1,-1,-1,4,-1,5,6,-1},
      {-1,-1,-1,-1,4,-1,5,6,-1},
      {-1,-1,-1,-1,4,-1,5,6,-1},
      {-1,-1,-1,-1,4,-1,5,6,-1},
      {7,8,-1,-1,-1,16,-1,-1,-1},
      {1,1,9,10,-1,1,-1,-1,1},
      {2,2,9,10,-1,2,-1,-1,2},
      {4,4,4,4,-1,4,-1,-1,4},
      {5,5,5,5,-1,5,-1,-1,5},
      {7,7,7,7,-1,7,-1,-1,7}};
  int SLR_goto[17][3]={
      {1,2,3},{-1,-1,-1},{-1,-1,-1},{-1,-1,-1},{11,2,3},{-1,-1,-1},{-1,-1,-1},{-1,12,3},
      {-1,13,3},{-1,-1,14},{-1,-1,15},{-1,-1,-1},{-1,-1,-1},{-1,-1,-1},{-1,-1,-1},{-1,-1,-1},
      {-1,-1,-1}};
  production p[10];

  create_production(p);
  init_char_stack(&input);
  init_state_stack(&state);
  maincc();

  FILE* fp;
	fp=fopen("tokenxl.txt","r");//���ļ������ȡ����
	char buf[200];

    int tempp=0;
    while (fgets(buf, sizeof(buf), fp) != NULL)
    {
        int len=strlen(buf);
        for(int n=0; n<len;n++)
		{
		    if( (buf[n]!='\n') &&(n==0))
            {
                tempp=(int)buf[n]-48;
            }
            else if( (n==1)&&(buf[n]!='\n') )
            {
                tempp=tempp*10+(int)buf[n]-48;
            }
            else if(buf[n]=='\n')
            {
                ch[lll++]=tempp;
                j++;
            }
		}
    }

  for(j=j-1;j>=0;j--)
    char_push(&input,ch[j]);
  state_push(&state,0);

  SLR_driver(&state,&input,action1,action2,SLR_goto,p);
  return 0;
}
