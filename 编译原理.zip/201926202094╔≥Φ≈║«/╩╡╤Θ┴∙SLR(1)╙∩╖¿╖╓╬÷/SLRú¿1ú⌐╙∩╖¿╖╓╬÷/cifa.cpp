#include <iostream>
#include <string.h>
#include <stdlib.h>
char input[200];//�����洢��Ҫ������Դ����
int i,k=0;//i����input����,k����token����
int ni=0,di=0,lines=1;//ni��¼��ʶ����ַ,di��¼������ַ,linesָʾ��ǰ����
char keyword[50][50]={"if","else","for","while","break","return","continue","float","int","char"};
int keynum[50]={1,2,3,4,5,6,7,8,9,10};
char Namel[50][50];
char Constl[50][50];
struct a
{
    int clas;
    char seman[10];
}token[80];    //������������
struct e
{
    int line;
    char info[30];
}err[20];//��������ݼ�¼
struct pte
{
    int line;
    int a[20]={0};
}pt[3];
int ps=0,pm=0,pb=0;
int ei=0;//ָʾ�ڼ�������
int isletter(char x)
{
    if( (x>='a'&&x<='z')||(x>='A'&&x<='Z') )
        return 1;
    else
        return 0;
}
int isdigit(char x)
{
    if((x>='0'&&x<='9'))
        return 1;
    else
        return 0;
}
void print_token(int k)
{
    int j;
    FILE* fp2=fopen("token.txt","w");
    FILE* fp0=fopen("tokenxl.txt","w");
    printf("\n  token list:");
    for(j=0;j<k;j++){
        printf("\n %3d token.class:%5d  token.seman:%s",j+1,token[j].clas,token[j].seman);
        fprintf(fp2,"%3d token.class:%5d  token.seman:%s\n",j+1,token[j].clas,token[j].seman);
        fprintf(fp0,"%d\n",token[j].clas);
    }
    fclose(fp2);
	fclose(fp0);
    FILE* fp3=fopen("Namel.txt","w");
    for(j=0;j<ni;j++)
    {
        fprintf(fp2,"��ַ:%3d ��ʶ��:%s\n",j,Namel[j]);
    }
    fclose(fp3);

    FILE* fp4=fopen("Constl.txt","w");
    for(j=0;j<di;j++)
    {
        fprintf(fp4,"��ַ:%3d ����:%s\n",j,Constl[j]);
    }
    fclose(fp4);
}
int iskeyword(char s[])//�ж��Ƿ��Ǳ�����
{

	for(int u=0;u<10;u++)
	{
		if(strcmp(s,keyword[u]) == 0)
			return keynum[u];
	}
	return 0;
}
void next_token()
{
    char ch,name[10];//name������ʱ�����ַ�,ʶ���ʶ���ͳ���
    int state,l;
    ch=input[i];
    state=0;
    l=0;//ָʾname�±�

    while(ch==' '||ch=='\t'||ch=='\n')//�����հ�
    {
        if(ch=='\n'){//����ǻ�����Ҫʶ�����
            token[k].clas=37;
            strcpy(token[k].seman,"���з�");
            k++;
            lines++;//�������з���������1
            return;
        }
        ch=input[++i];
    }

    int num;
    for(num=0;num<10;num++){//ÿ�ζ���name��������,������һ�ε����ݱ���������Ӱ��
        name[num]=NULL;
    }
    while(1){
        switch(state)
        {
            case 0:
                if(ch=='+')
                {
                    state=1;
                }
                else if(ch=='-')
                {
                    state=2;
                }
                else if(ch=='*')
                {
                    state=3;
                }
                else if(ch=='/')
                {
                    state=4;
                }
                else if(ch=='%')
                {
                    state=5;
                }
                else if(ch=='>')
                {
                    state=6;
                }
                else if(ch=='<')
                {
                    state=7;
                }
                else if(ch=='=')
                {
                    state=8;
                }
                else if(ch=='!')
                {
                    state=9;
                }
                else if(ch=='&')
                {
                    state=10;
                }
                else if(ch=='|')
                {
                    state=11;
                }
                else if(ch==',')
                {
                    state=12;
                }
                else if(ch=='[')
                {
                    state=13;
                }
                else if(ch==']')
                {
                    state=14;
                }
                else if(ch=='(')
                {
                    state=15;
                }
                else if(ch==')')
                {
                    state=16;
                }
                else if(ch=='{')
                {
                    state=17;
                }
                else if(ch=='}')
                {
                    state=18;
                }
                else if(ch==';')
                {
                    state=19;
                }
                else if(ch=='.')
                {
                    state=20;
                }
                else if(isletter(ch))//��������ĸ
                {
                    name[l++]=ch;
                    state=21;
                }
                else if(isdigit(ch))//����������
                {
                    name[l++]=ch;
                    state=22;
                }
                else if(ch=='#')
                {
                    i--;
                    return;
                }
                else
                {
                    err[ei].line=lines;
                    strcpy(err[ei].info,"δ������ַ�����");
                    ei++;
                    return;
                }
                break;
            case 21:
                ch=input[++i];
                if(isletter(ch)||isdigit(ch))//�ж���ĸ����һ���Ƿ������ֻ�����ĸ,�����,��Ҫ��������
                {
                    name[l++]=ch;
                    state=21;
                    break;
                }
                else
                {
                    if(iskeyword(name)!=0)//�ж��Ƿ�Ϊ������
                    {
                        token[k].clas=iskeyword(name);
                        strcpy(token[k].seman,name);
                        k++;
                        i--;
                    }
                    else        //�ж�Ϊ��ʶ��
                    {
                        for(int aa=0;aa<ni;aa++)//�жϱ�ʶ���Ƿ��ظ�,�ظ��Ͳ�Ҫ�ظ����
                        {
                            if(strcmp(Namel[aa],name)==0)
                            {
                                token[k].clas=11;
                                itoa(aa,token[k].seman,10);
                                k++;
                                i--;
                                return;
                            }
                        }
                        token[k].clas=11;
                        strcpy(Namel[ni],name);
                        itoa(ni,token[k].seman,10);//��10����ת����ַΪ�ַ��浽token[k].seman����
                        ni++;
                        k++;
                        i--;    //������һ��input�����ٴ��ж�
                    }
                    return;
                }
            case 22:
                ch=input[++i];
                if(isdigit(ch))//�ٴ����������ٴ��ж�,ֱ����������
                {
                    name[l++]=ch;
                    state=22;
                    break;
                }
                else if(ch=='.')
                {
                    state=23;
                    if(!isdigit(input[i+1]))
                    {
                        err[ei].line=lines;
                        strcpy(err[ei].info,"�Ƿ�С��");
                        ei++;
                        i++;
                        ch=input[++i];
                        while(isletter(ch)||isdigit(ch))//�������������ĸ������ȫ��������,��һ���Ƿ���ʶ��
                        {
                            ch=input[++i];
                        }
                        i--;
                        return;
                    }
                    name[l++]='.';
                    break;
                }
                else if(isletter(ch))//���ֺ��������ĸ
                {
                    err[ei].line=lines;//��¼��������
                    strcpy(err[ei].info,"�Ƿ���ʶ��");//��¼����ԭ��
                    ei++;
                    ch=input[++i];
                    while(isletter(ch)||isdigit(ch))//�������������ĸ������ȫ��������,��һ���Ƿ���ʶ��
                    {
                        ch=input[++i];
                    }
                    i--;
                }
                else//�ж�Ϊ����
                {

                    for(int aa=0;aa<ni;aa++)//�жϳ����Ƿ��ظ�,�ظ��Ͳ�Ҫ�ظ����
                    {
                        if(strcmp(Constl[aa],name)==0)
                        {
                            token[k].clas=12;
                            itoa(aa,token[k].seman,10);
                            k++;
                            i--;
                            return;
                        }
                    }

                    token[k].clas=12;
                    strcpy(Constl[di],name);
                    itoa(di,token[k].seman,10);//ת�����¼������ַ
                    di++;
                    k++;
                    i--;
                }
                return;

            case 23:
                ch=input[++i];
                if(isdigit(ch))
                {
                    name[l++]=ch;
                    state=23;
                    break;
                }
                else if(isletter(ch))
                {
                    err[ei].line=lines;//��¼��������
                    strcpy(err[ei].info,"�Ƿ�С��");//��¼����ԭ��
                    ei++;
                    ch=input[++i];
                    while(isletter(ch)||isdigit(ch))//�������������ĸ������ȫ��������,��һ���Ƿ���ʶ��
                    {
                        ch=input[++i];
                    }
                    i--;
                    return;
                }
                else if(ch=='.')
                {
                    err[ei].line=lines;//��¼��������
                    strcpy(err[ei].info,"�Ƿ�С��");//��¼����ԭ��
                    ei++;
                    ch=input[++i];
                    while(isletter(ch)||isdigit(ch))//�������������ĸ������ȫ��������,��һ���Ƿ���ʶ��
                    {
                        ch=input[++i];
                    }
                    i--;
                    return;
                }
                else
                {
                    for(int aa=0;aa<ni;aa++)//�жϳ����Ƿ��ظ�,�ظ��Ͳ�Ҫ�ظ����
                    {
                        if(strcmp(Constl[aa],name)==0)
                        {
                            token[k].clas=12;
                            itoa(aa,token[k].seman,10);
                            k++;
                            i--;
                            return;
                        }
                    }

                    token[k].clas=12;
                    strcpy(Constl[di],name);
                    itoa(di,token[k].seman,10);//ת�����¼������ַ
                    di++;
                    k++;
                    i--;
                    return;
                }
            case 1:
                token[k].clas=13;
                strcpy(token[k].seman,"+");
                k++;
                return;
            case 2:
                token[k].clas=14;
                strcpy(token[k].seman,"-");
                k++;
                return;
            case 3:
                token[k].clas=15;
                strcpy(token[k].seman,"*");
                k++;
                return;
            case 4:
                ch=input[++i];
                if(ch=='/')//�ж��Ƿ���//ע��
                {
                    while(input[++i]!='\n')
                    {
                        if(input[i]=='#')//�����ļ��Ľ�����ֱ�ӷ���
                        {
                            i--;
                            return;
                        }
                    }
                    lines++;//�������о�������1
                    return;
                }

                /*  */
                else if(ch=='*')//�ж��Ƿ���/* &/ע��
                {
                    while( (input[i+1]!='*') || (input[i+2]!='/') )
                    {
                        if( (input[i+1]=='#') || (input[i+2]=='#') )//����Ƿ����ļ��Ľ���Ҳû��ƥ�䵽*/
                        {
                            i++;
                            return;
                        }
                        if(input[i+1]=='\n')    lines++;//��������������1
                        i++;
                    }
                    i=i+2;
                    return;
                }
                else//�ж�Ϊ����
                {
                    token[k].clas=16;
                    strcpy(token[k].seman,"/");
                    k++;
                    i--;
                    return;
                }

            case 5:
                token[k].clas=17;
                strcpy(token[k].seman,"%");
                k++;
                return;
            case 6:
                ch=input[++i];
                if(ch!='=')//�ж�>�����Ƿ���=
                {
                    token[k].clas=18;
                    strcpy(token[k].seman,">");
                    k++;
                    i--;
                    return;
                }
                else if(ch=='=')//����=�ͺ�>���>=
                {
                    token[k].clas=19;
                    strcpy(token[k].seman,">=");
                    k++;
                    return;
                }

            case 7:
                ch=input[++i];
                if(ch!='=')//�ж�<�����Ƿ���=
                {
                    token[k].clas=20;
                    strcpy(token[k].seman,"<");
                    k++;
                    i--;
                    return;
                }
                else if(ch=='=')//����=�ͺ�<���<=
                {
                    token[k].clas=21;
                    strcpy(token[k].seman,"<=");
                    k++;
                    return;
                }
            case 8:
                ch=input[++i];
                if(ch!='=')//�ж�=�����Ƿ���=
                {
                    token[k].clas=28;
                    strcpy(token[k].seman,"=");
                    k++;
                    i--;
                    return;
                }
                else if(ch=='=')//����=�ͺ�=���==
                {
                    token[k].clas=23;
                    strcpy(token[k].seman,"==");
                    k++;
                    return;
                }
            case 9:
                ch=input[++i];
                if(ch!='=')
                {
                    token[k].clas=24;
                    strcpy(token[k].seman,"!");
                    k++;
                    i--;
                    return;
                }
                else if(ch=='=')
                {
                    token[k].clas=22;
                    strcpy(token[k].seman,"!=");
                    k++;
                    return;
                }
            case 10:
                ch=input[++i];
                if(ch!='&')//������,����ʶ�𵥶���һ��&
                {
                    i--;
                    err[ei].line=lines;
                    strcpy(err[ei].info,"�������");
                    ei++;
                    return;
                }
                else if(ch=='&')
                {
                    token[k].clas=25;
                    strcpy(token[k].seman,"&&");
                    k++;
                    return;
                }
            case 11:
                ch=input[++i];
                if(ch!='|')//������,����ʶ�𵥶���һ��|
                {
                    i--;
                    err[ei].line=lines;
                    strcpy(err[ei].info,"�������");
                    ei++;
                    return;
                }
                else if(ch=='|')
                {
                    token[k].clas=25;
                    strcpy(token[k].seman,"||");
                    k++;
                    return;
                }
            case 12:
                token[k].clas=27;
                strcpy(token[k].seman,",");
                k++;
                return;
            case 13:
                token[k].clas=29;
                strcpy(token[k].seman,"[");
                pt[1].a[pm++]=1;
                pt[1].line=lines;
                k++;
                return;
            case 14:
                token[k].clas=30;
                strcpy(token[k].seman,"]");
                if(pm==0)
                {
                    pt[1].a[pm++]=2;
                    pt[1].line=lines;
                }
                else if(pt[1].a[pm-1]==1)
                {
                    pt[1].a[pm-1]=0;
                    pm--;
                }
                else
                {
                    pt[1].a[pm++]=2;
                    pt[1].line=lines;
                }
                k++;
                return;
            case 15:
                token[k].clas=31;
                strcpy(token[k].seman,"(");
                pt[0].a[ps++]=1;
                pt[0].line=lines;
                k++;
                return;
            case 16:
                token[k].clas=32;
                strcpy(token[k].seman,")");
                if(ps==0)
                {
                    pt[0].a[ps++]=2;
                    pt[0].line=lines;
                }
                else if(pt[0].a[ps-1]==1)
                {
                    pt[0].a[ps-1]=0;
                    ps--;
                }
                else
                {
                    pt[0].a[ps++]=2;
                    pt[0].line=lines;
                }
                k++;
                return;
            case 17:
                token[k].clas=33;
                strcpy(token[k].seman,"{");
                pt[2].a[pb++]=1;
                pt[2].line=lines;
                k++;
                return;
            case 18:
                token[k].clas=34;
                strcpy(token[k].seman,"}");
                if(pb==0)
                {
                    pt[2].a[pb++]=2;
                    pt[2].line=lines;
                }
                else if(pt[2].a[pb-1]==1)
                {
                    pt[2].a[pb-1]=0;
                    pb--;
                }
                else
                {
                    pt[2].a[pb++]=2;
                    pt[2].line=lines;
                }
                k++;
                return;
            case 19:
                token[k].clas=35;
                strcpy(token[k].seman,";");
                k++;
                return;
            case 20:
                token[k].clas=36;
                strcpy(token[k].seman,".");
                k++;
                return;
        }
    }

}

int maincc()
{
    int j;
    char ch;
    printf("��������,��#����\n");
//    while((ch=getchar())!='#')
//        input[j++]=ch;
    FILE* fp;
	fp=fopen("test.txt","r");//���ļ������ȡ����
	char buf[200];
	while(fgets(buf,100,fp)!=NULL)//��ȡ�����ݲ�Ϊ��
	{
		int len=strlen(buf);
		for(int n=0; n<len;n++)
		{
			input[j++]=buf[n];//�����ݷŵ�input��������
		}
	}
    input[j]='#';//������������һ��������#
    i=0;
    while(input[i]!='#'){//����ʶ��
        next_token();
        i++;
    }
    if(input[i]=='#')//���������һ�����ݱ�ʾʶ��ɹ���
    {
        token[k].clas=38;
        strcpy(token[k].seman,"#");
        k++;
        printf("\n\nscanner is succend!");
        print_token(k);
    }
    printf("\n\nerror list:");
    for(int num=0;num<ei;num++)//���м������Ĵ������ݴ�ӡ����
    {
        printf("\nerror:%d line:%d %s",num+1,err[num].line,err[num].info);
    }
    printf("\n");
    int nume=ei;
    for(int num=0;num<3;num++)
    {
        for(int num2=0;num2<20;num2++)
        {
            if(pt[num].a[num2]!=0)
                printf("\neror:%d line:%d %s",++nume,pt[num].line,"����ƥ�����");
        }
    }
    fclose(fp);
    return 0;
}
